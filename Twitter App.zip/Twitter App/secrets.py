# All twitter app information goes here.  Add information in appropriate blocks

C_KEY = ""
C_SECRET = ""
A_TOKEN = ""
A_TOKEN_SECRET = ""

